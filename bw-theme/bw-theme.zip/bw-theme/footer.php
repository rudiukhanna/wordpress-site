<!-- Footer --> 
<div class="footer">
    <div class="container">
        <div class="footer__text">
        <?= CFS()->get('footer_copy'); ?>
        </div>
    </div>
</div>

<?php wp_footer();?> 
</body>
</html>